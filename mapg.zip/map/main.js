var width = 960,
    height = 500;
var attributeArray = [];
var file;

var format = d3.format(",");

var projection = d3.geo.mercator()
                  .translate([width / 2, height / 2])
                   .scale([120]);
var path = d3.geo.path().projection(projection);

var color = d3.scale.linear() //  
			  .range(["rgb(0,0,0)","rgb(171,221,164) ","rgb(254,224,139)","rgb(253,174,97)", "rgb(215, 25, 28)"]);
var legendText = ["Low Income", "Low Middle", "Upper Middle", "High Income", "NA"];
var svg = d3.select("body")
			.append("svg")
			.attr("width", width)
			.attr("height", height);

var div = d3.select("body")
		    .append("div")   
    		.attr("class", "tooltip")               
    		.style("opacity", 0);
d3.csv("processed_income_data.csv", function(data) {
	color.domain([0,1,2,3,4]);

	d3.json("countries.json", function(json){
		// Loop through each Country data value in the .csv file
		for (var i = 0; i < data.length; i++) {
			var dataCountry = data[i].Country; // grabs country name 
			var dataValue = data[i].Income; // grabs their income data
			var dataYear= data[i].Year; // grabs their year 
			
			// find the corresponding data inside the country.json file
			for (var j = 0; j < json.features.length; j++)  {

				var jsonCountry = json.features[j].properties.name;
				if (dataCountry == jsonCountry) {
					for(var k in dataCountry[i]) {
						if(k != 'Country'){
							if(attributeArray.indexOf(k) == -1) { 
							       attributeArray.push(k);  // add new column headings to our array for later
							 }
							 
							 json.features[i].properties[k] = Number(dataCountry[j][k]);
							 //json.features[j].properties.Income = Number(dataValue[j][k]); 
							 //json.features[j].properties.Year = Number(dataYear[j][k]);
						}

					}
					//current code only displays data for 2019, why?
					// Copy the data value into the JSONcountry_name
						json.features[j].properties.Income = dataValue; 
						json.features[j].properties.Year = dataYear;

						// Stop looking through the JSON
						
						break;
				}
			}
		}
		var legend = d3.select("body").append("svg")
		      			.attr("class", "legend")
		     			.attr("width", 140)
		    			.attr("height", 200)
		   				.selectAll("g")
		   				.data(color.domain().slice().reverse())
		   				.enter()
		   				.append("g")
		     			.attr("transform", function(d, i) { return "translate(0," + i * 20 + ")"; });

		  	legend.append("rect")
		   		  .attr("width", 18)
		   		  .attr("height", 18)
		   		  .style("fill", color);

		  	legend.append("text")
		  		  .data(legendText)
		      	  .attr("x", 24)
		      	  .attr("y", 9)
		      	  .attr("dy", ".35em")
		      	  .text(function(d) { return d; });

// do we need to loop through year max and min
		 // add the Income data to the map that we have 
		svg.selectAll("path")
			.data(json.features)
			.enter()
			.append("path")
			.attr("d", path)
			.style("stroke", "#fff")
			.style("stroke-width", "1")
			.style("fill", function(d) {
				var value = d.properties.Income;

					if (value){
					//If value exists…
						return color(value);
					} else {
					//If value is undefined…
					return "rgb(213,222,217)";
					}
			});
		console.log(json.features); // I use print statement here to look at my json.features data
		

		// Tslider for year dummy code
		var bwidth = 420,
		    barHeight = 25;

		/*var x = d3.scale.linear()
		    .domain([0, d3.max(data, function(d) {return d.properties.Year; })])
		    .range([0, bwidth]);
		    */
		var x = d3.scale.linear()
		     .domain([0, d3.max(json.features, function(d) {return d.properties.Year; })])
		     .range([0, 32]);


		var chart = d3.select(".chart")
		    .attr("width", bwidth)
		    .attr("height", barHeight * data.length);

		var bar = chart.selectAll("path")
		    .data(json.features)
		  .enter().append("path")
		    .attr("transform", function(d, i) { return "translate(0," + i * barHeight + ")"; });

		bar.append("rect")
		    .attr("width", function(d) { return x(d.properties.Year); })
		    .attr("height", barHeight - 2);

		bar.append("text")
		    .attr("x", function(d) { return x(d.properties.Year) - 3; })
		    .attr("y", barHeight / 2)
		    .attr("dy", ".3em")
		    .text(function(d) { return d.properties.Year; });

		d3.select('#slider2').call(d3.slider().value( [1988, 2019 ] ));
		

		

	});
});
